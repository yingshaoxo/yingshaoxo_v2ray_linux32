package vmess

// example
const AlterID = "VMessCtxInterface_AlterID"
